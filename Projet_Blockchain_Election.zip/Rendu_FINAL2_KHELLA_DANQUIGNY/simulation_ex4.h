#ifndef SIMULATION_H
#define SIMULATION_H

#include "proto_rsa.h"
#include "manip_struct.h"

int recherche_element(int val, int *tab, int size);
void generate_random_data(int nv, int nc);

#endif //SIMULATION_H